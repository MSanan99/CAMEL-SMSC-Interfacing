import java.io.File;

import javax.xml.parsers.DocumentBuilderFactory;

import org.mobicents.protocols.api.IpChannelType;
import org.mobicents.protocols.sctp.netty.NettySctpManagementImpl;

import org.mobicents.protocols.ss7.cap.CAPStackImpl;
import org.mobicents.protocols.ss7.cap.api.CAPDialog;
import org.mobicents.protocols.ss7.cap.api.CAPMessage;
import org.mobicents.protocols.ss7.cap.api.CAPMessageType;
import org.mobicents.protocols.ss7.cap.api.CAPProvider;
import org.mobicents.protocols.ss7.cap.api.dialog.CAPGeneralAbortReason;
import org.mobicents.protocols.ss7.cap.api.dialog.CAPNoticeProblemDiagnostic;
import org.mobicents.protocols.ss7.cap.api.dialog.CAPUserAbortReason;
import org.mobicents.protocols.ss7.cap.api.errors.CAPErrorMessage;
import org.mobicents.protocols.ss7.cap.api.service.sms.CAPDialogSms;
import org.mobicents.protocols.ss7.cap.api.service.sms.CAPServiceSmsListener;
import org.mobicents.protocols.ss7.cap.api.service.sms.ConnectSMSRequest;
import org.mobicents.protocols.ss7.cap.api.service.sms.ContinueSMSRequest;
import org.mobicents.protocols.ss7.cap.api.service.sms.EventReportSMSRequest;
import org.mobicents.protocols.ss7.cap.api.service.sms.FurnishChargingInformationSMSRequest;
import org.mobicents.protocols.ss7.cap.api.service.sms.InitialDPSMSRequest;
import org.mobicents.protocols.ss7.cap.api.service.sms.ReleaseSMSRequest;
import org.mobicents.protocols.ss7.cap.api.service.sms.RequestReportSMSEventRequest;
import org.mobicents.protocols.ss7.cap.api.service.sms.ResetTimerSMSRequest;
import org.mobicents.protocols.ss7.cap.api.primitives.MonitorMode;
import org.mobicents.protocols.ss7.cap.api.service.sms.primitive.EventTypeSMS;
import org.mobicents.protocols.ss7.cap.api.service.sms.primitive.SMSEvent;
import org.mobicents.protocols.ss7.cap.service.sms.primitive.SMSEventImpl;

import org.mobicents.protocols.ss7.m3ua.ExchangeType;
import org.mobicents.protocols.ss7.m3ua.Functionality;
import org.mobicents.protocols.ss7.m3ua.IPSPType;
import org.mobicents.protocols.ss7.m3ua.impl.M3UAManagementImpl;
import org.mobicents.protocols.ss7.m3ua.impl.parameter.ParameterFactoryImpl;
import org.mobicents.protocols.ss7.m3ua.parameter.RoutingContext;
import org.mobicents.protocols.ss7.m3ua.parameter.TrafficModeType;

import org.mobicents.protocols.ss7.indicator.NatureOfAddress;
import org.mobicents.protocols.ss7.indicator.NumberingPlan;
import org.mobicents.protocols.ss7.indicator.RoutingIndicator;

import org.mobicents.protocols.ss7.sccp.LoadSharingAlgorithm;
import org.mobicents.protocols.ss7.sccp.OriginationType;
import org.mobicents.protocols.ss7.sccp.RuleType;
import org.mobicents.protocols.ss7.sccp.SccpProvider;
import org.mobicents.protocols.ss7.sccp.impl.SccpStackImpl;
import org.mobicents.protocols.ss7.sccp.impl.parameter.BCDEvenEncodingScheme;
import org.mobicents.protocols.ss7.sccp.impl.parameter.GlobalTitle0100Impl;
import org.mobicents.protocols.ss7.sccp.impl.parameter.SccpAddressImpl;
import org.mobicents.protocols.ss7.sccp.parameter.GlobalTitle;
import org.mobicents.protocols.ss7.sccp.parameter.SccpAddress;

import org.mobicents.protocols.ss7.tcap.TCAPStackImpl;
import org.mobicents.protocols.ss7.tcap.api.TCAPProvider;
import org.mobicents.protocols.ss7.tcap.api.TCAPStack;
import org.mobicents.protocols.ss7.tcap.asn.comp.PAbortCauseType;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

/**
 * CAMEL SMS proxy.
 *
 * Runs as a TRUE CLIENT at every layer:
 *   SCTP/TCP : outbound association (addAssociation, no addServer / startServer)
 *   M3UA     : Functionality.AS + IPSPType.CLIENT (this side INITIATES the M3UA link)
 *   SCCP     : peer (we send/receive UDT to/from remote SPC; no listening role)
 *   TCAP/CAP : peer dialogs; we still implement CAPServiceSmsListener so we can
 *              receive InitialDPSMS triggers from the network when dialogs are
 *              opened *to us*, but we never bind a server socket.
 *
 * The class name is kept as CamelSmsServer to match the JAR's mainClass; the
 * "Server" in the name is the daemon/process sense, not a network role.
 */
public class CamelSmsServer implements CAPServiceSmsListener {

    /** Parsed from config.xml — SIGTRAN must match the remote M3UA/SCTP peer. */
    private String localIp = "127.0.0.1";
    private int localPort = 2905;
    private String remoteIp = "127.0.0.1";
    private int remotePort = 2905;

    /** Must match the name passed to M3UA {@code createAspFactory(..., name)}. */
    private String m3uaAssociationName = "aspClient1";

    private IpChannelType sigtranChannelType = IpChannelType.TCP;

    private long routingContextId = 100;
    private int m3uaTrafficMode = TrafficModeType.Loadshare;

    private int localPointCode = 5801;
    private int remotePointCode = 842;
    private int remoteSsn = 8;
    private int localSsn = 147;
    private int networkIndicator = 2;

    /** Global titles — must match fake-smsc {@code config.xml} GT digits. */
    private String localGt = "6749991001";
    private String remoteGt = "6749991000";

    private NettySctpManagementImpl transportManagement;

    private M3UAManagementImpl m3uaManagement;

    private final ParameterFactoryImpl m3uaParameterFactory =
            new ParameterFactoryImpl();

    private SccpStackImpl sccpStack;
    private SccpProvider sccpProvider;

    private TCAPStack tcapStack;
    private TCAPProvider tcapProvider;

    private CAPStackImpl capStack;
    private CAPProvider capProvider;

    public static void main(String[] args) throws Exception {

        CamelSmsServer server = new CamelSmsServer();

        server.loadConfig("config.xml");

        server.initializeStack();

        System.out.println("CAMEL SMS Client started...");
    }

    private void loadConfig(String file) throws Exception {

        Document doc = DocumentBuilderFactory
                .newInstance()
                .newDocumentBuilder()
                .parse(new File(file));

        Element root = doc.getDocumentElement();

        localIp = textContent(root, "local-ip", localIp);
        localPort = parseInt(root, "local-port", localPort);
        remoteIp = textContent(root, "remote-ip", remoteIp);
        remotePort = parseInt(root, "remote-port", remotePort);

        m3uaAssociationName =
                textContent(root, "m3ua-association-name", m3uaAssociationName);

        sigtranChannelType =
                parseChannelType(textContent(root, "ip-channel-type", null));

        routingContextId =
                parseLong(root, "routing-context", routingContextId);
        m3uaTrafficMode =
                parseInt(root, "traffic-mode", m3uaTrafficMode);

        localPointCode =
                parseInt(root, "local-point-code", localPointCode);
        remotePointCode =
                parseInt(root, "remote-point-code", remotePointCode);
        remoteSsn =
                parseInt(root, "remote-ssn", remoteSsn);
        localSsn =
                parseInt(root, "local-ssn", localSsn);
        networkIndicator =
                parseInt(root, "network-indicator", networkIndicator);

        localGt = textContent(root, "local-gt", localGt);
        remoteGt = textContent(root, "remote-gt", remoteGt);

        System.out.println("Config loaded.");
    }

    private static String textContent(Element root, String tag, String defaultValue) {

        NodeList nodes = root.getElementsByTagName(tag);
        if (nodes.getLength() == 0) {
            return defaultValue;
        }
        String v = nodes.item(0).getTextContent();
        if (v == null) {
            return defaultValue;
        }
        v = v.trim();
        return v.isEmpty() ? defaultValue : v;
    }

    private static int parseInt(Element root, String tag, int defaultValue) {

        String raw = textContent(root, tag, null);
        if (raw == null) {
            return defaultValue;
        }
        return Integer.parseInt(raw);
    }

    private static long parseLong(Element root, String tag, long defaultValue) {

        String raw = textContent(root, tag, null);
        if (raw == null) {
            return defaultValue;
        }
        return Long.parseLong(raw);
    }

    private static IpChannelType parseChannelType(String raw) {

        if (raw == null || raw.isEmpty()) {
            return IpChannelType.TCP;
        }
        switch (raw.trim().toUpperCase()) {
            case "SCTP":
                return IpChannelType.SCTP;
            case "TCP":
            default:
                return IpChannelType.TCP;
        }
    }

    private void initializeStack() throws Exception {

        initTransport();

        initM3UA();

        initSCCP();

        initTCAP();

        initCAP();

        printCapRoutingHint();

        System.out.println(
                "FULL STACK INITIALIZED (role=CLIENT at every layer).");
    }

    /**
     * Explains why {@link #onInitialDPSMSRequest} may never log anything even when
     * M3UA/SCTP is up and an SMSC shows MAP traffic.
     */
    private void printCapRoutingHint() {

        System.out.println("");
        System.out.println(
                "CAP listener is active. InitialDPSMS only arrives if the peer routes");
        System.out.println(
                "a TCAP BEGIN (CAP initialDPSMS) to YOUR address: DPC="
                        + localPointCode
                        + "  SSN="
                        + localSsn
                        + "  (NI="
                        + networkIndicator
                        + ").");
        System.out.println(
                "In real networks InitialDPSMS is sent by the MSC/VLR on MO SMS, not by");
        System.out.println(
                "the SMSC. Many labs use SSN 149 for gsmSCF — if your simulator targets");
        System.out.println(
                "another SSN, set <local-ssn> in config.xml to match.");
        System.out.println(
                "Any CAP primitive received will also print under [CAP RX].");
        System.out.println("");
    }

    private void initTransport() throws Exception {

        this.transportManagement =
                new NettySctpManagementImpl("camelSmsClient");

        this.transportManagement.start();
        this.transportManagement.removeAllResourses();

        /*
         * CLIENT mode: addAssociation creates an OUTBOUND association from
         * (localIp:localPort) to (remoteIp:remotePort). No addServer / startServer
         * is used, so we never bind a listening socket.
         *
         * Do not call startAssociation here: the association needs an
         * AssociationListener first. M3UA registers AspFactoryImpl as that listener
         * in createAspFactory; startAsp(...) then starts the SCTP/TCP association.
         */

        this.transportManagement.addAssociation(
                localIp,
                localPort,
                remoteIp,
                remotePort,
                m3uaAssociationName,
                sigtranChannelType,
                null);

        System.out.println(
                "Transport configured as CLIENT (association "
                        + m3uaAssociationName
                        + " dials "
                        + localIp + ":" + localPort
                        + " -> "
                        + remoteIp + ":" + remotePort
                        + " over " + sigtranChannelType
                        + "; socket starts when M3UA ASP starts).");
    }

    private void initM3UA() throws Exception {

        this.m3uaManagement =
                new M3UAManagementImpl("camelSmsClient", ".");

        this.m3uaManagement.setTransportManagement(
                this.transportManagement);

        this.m3uaManagement.start();
        this.m3uaManagement.removeAllResourses();

        /*
         * Local AS, this node's M3UA Application Server.
         */

        RoutingContext rc =
                this.m3uaParameterFactory.createRoutingContext(
                        new long[]{routingContextId});

        TrafficModeType trafficMode =
                this.m3uaParameterFactory.createTrafficModeType(
                        m3uaTrafficMode);

        /*
         * IPSPType.CLIENT is the actual CLIENT/SERVER switch in M3UA — this side
         * INITIATES the M3UA association. Functionality.AS marks us as the user
         * (Application Server), which is the standard role for a CAMEL/SCP client.
         */
        this.m3uaManagement.createAs(
                "localAs1",
                Functionality.AS,
                ExchangeType.SE,
                IPSPType.CLIENT,
                rc,
                trafficMode,
                1,
                null);

        /*
         * ASP bound to the outbound SCTP/TCP association.
         */

        this.m3uaManagement.createAspFactory(
                "aspClient1",
                m3uaAssociationName);

        this.m3uaManagement.assignAspToAs(
                "localAs1",
                "aspClient1");

        /*
         * Route SCCP (SI=3) toward the peer DPC via this AS. Without this,
         * sendMessage fails with "No AS found for routing message" when SCCP
         * tries to ship TCAP/CAP replies (opc=local, dpc=remote).
         *
         * Same shape as fake-smsc addRoute(remotePointCode, localPointCode, 3, ...).
         */
        final int mtp3ServiceIndicatorSccp = 3;
        this.m3uaManagement.addRoute(
                remotePointCode,
                localPointCode,
                mtp3ServiceIndicatorSccp,
                "localAs1");

        this.m3uaManagement.startAsp("aspClient1");

        System.out.println(
                "M3UA initialized as CLIENT (Functionality.AS, IPSPType.CLIENT, "
                        + "AS=localAs1, ASP=aspClient1).");
    }

    private void initSCCP() throws Exception {

        this.sccpStack =
                new SccpStackImpl("CamelSmsClientSccp");

        this.sccpStack.setMtp3UserPart(
                1,
                this.m3uaManagement);

        this.sccpStack.start();

        this.sccpProvider =
                this.sccpStack.getSccpProvider();

        this.sccpStack.removeAllResourses();

        /*
         * MTP3 routing for SCCP.
         *
         * Service Access Point: tells SCCP which OPC (this node) is reachable via
         * which MTP3 user part (id=1 = our M3UA management). Without this, every
         * incoming message looks "nonlocal dpc=<our-spc>" and gets dropped.
         */

        int sapId = 1;
        int mtp3UserPartId = 1;
        int destId = 1;

        this.sccpStack.getRouter()
                .addMtp3ServiceAccessPoint(
                        sapId,
                        mtp3UserPartId,
                        localPointCode,
                        networkIndicator,
                        0,
                        null);

        /*
         * MTP3 Destination: how to reach the remote SPC through the above SAP.
         * Range firstDpc..lastDpc covers a single peer here; SLS 0..255 with mask
         * 0xFF makes all SLS values eligible.
         */

        this.sccpStack.getRouter()
                .addMtp3Destination(
                        sapId,
                        destId,
                        remotePointCode,
                        remotePointCode,
                        0,
                        255,
                        255);

        /*
         * Remote SPC (peer is reachable / in service).
         */

        this.sccpStack.getSccpResource()
                .addRemoteSpc(
                        0,
                        remotePointCode,
                        0,
                        0);

        /*
         * Remote SSN (peer subsystem at the remote SPC, e.g. 8 = MSC, 6 = HLR,
         * 149 = gsmSCF — depends on your SMSC simulator).
         */

        this.sccpStack.getSccpResource()
                .addRemoteSsn(
                        0,
                        remotePointCode,
                        remoteSsn,
                        0,
                        false);

        /*
         * SCCP routing rules (mirror of FakeSmscSimulator.initM3uaAndSccp).
         *
         * Without REMOTE + localPattern, inbound UDTs from the SMSC hit
         * "no matching Rule found for local routing" and never reach TCAP/CAP.
         */
        SccpAddress remotePattern =
                new SccpAddressImpl(
                        RoutingIndicator.ROUTING_BASED_ON_GLOBAL_TITLE,
                        createGlobalTitle(remoteGt),
                        remotePointCode,
                        remoteSsn);
        this.sccpStack.getRouter().addRoutingAddress(1, remotePattern);
        this.sccpStack
                .getRouter()
                .addRule(
                        1,
                        RuleType.SOLITARY,
                        LoadSharingAlgorithm.Bit0,
                        OriginationType.LOCAL,
                        remotePattern,
                        "K",
                        1,
                        -1,
                        null,
                        0,
                        null);

        SccpAddress localPattern =
                new SccpAddressImpl(
                        RoutingIndicator.ROUTING_BASED_ON_GLOBAL_TITLE,
                        createGlobalTitle(localGt),
                        localPointCode,
                        localSsn);
        this.sccpStack.getRouter().addRoutingAddress(2, localPattern);
        this.sccpStack
                .getRouter()
                .addRule(
                        2,
                        RuleType.SOLITARY,
                        LoadSharingAlgorithm.Bit0,
                        OriginationType.REMOTE,
                        localPattern,
                        "K",
                        2,
                        -1,
                        null,
                        0,
                        null);

        System.out.println(
                "SCCP initialized (localSpc=" + localPointCode
                        + ", remoteSpc=" + remotePointCode
                        + ", ni=" + networkIndicator
                        + ", localSsn=" + localSsn
                        + ", remoteSsn=" + remoteSsn + ").");
    }

    private static GlobalTitle createGlobalTitle(String digits) {

        return new GlobalTitle0100Impl(
                digits,
                0,
                BCDEvenEncodingScheme.INSTANCE,
                NumberingPlan.ISDN_TELEPHONY,
                NatureOfAddress.INTERNATIONAL);
    }

    private void initTCAP() throws Exception {

        this.tcapStack =
                new TCAPStackImpl(
                        "CamelSmsClientTcap",
                        this.sccpProvider,
                        localSsn);

        this.tcapStack.start();

        this.tcapProvider =
                this.tcapStack.getProvider();

        System.out.println(
                "TCAP initialized.");
    }

    private void initCAP() throws Exception {

        this.capStack =
                new CAPStackImpl(
                        "CamelSmsClientCap",
                        this.tcapProvider);

        this.capStack.start();

        this.capProvider =
                this.capStack.getCAPProvider();

        this.capProvider
                .getCAPServiceSms()
                .addCAPServiceListener(this);

        this.capProvider
                .getCAPServiceSms()
                .acivate();

        System.out.println(
                "CAP initialized.");
    }

    /**
     * Called by the CAP stack when an MSC/SMSC triggers our gsmSCF with an
     * InitialDPSMS, i.e. a CAMEL Phase 3/4 "Mobile Originated SMS" trigger.
     *
     * Flow:
     *   1. Extract the interesting fields (calling, called, IMSI, SMSC, ...).
     *   2. Run a balance / policy check against the calling MSISDN.
     *   3. Respond on the SAME dialog:
     *        - Balance OK  -> RequestReportSMSEvent (notify only) + ContinueSMS
     *                         (CAMEL semantic for "proceed with the SMS").
     *        - Balance NOK -> ReleaseSMS (deny, with an SMS-RP cause).
     *   4. dialog.send() ships those CAP components back to the MSC.
     *
     * Note: we never call dialog.close() here. CAMEL Phase 3/4 SMS dialogs are
     * kept open after ContinueSMS so the network can later send us
     * EventReportSMS (oSmsSubmission / oSmsFailure). We close in
     * onEventReportSMSRequest below.
     */
    @Override
    public void onInitialDPSMSRequest(InitialDPSMSRequest ind) {

        try {

            CAPDialogSms dialog =
                    (CAPDialogSms) ind.getCAPDialog();

            String calling = addressOf(ind.getCallingPartyNumber());
            String called = addressOf(ind.getDestinationSubscriberNumber());
            String imsi = ind.getImsi() != null
                    ? ind.getImsi().getData()
                    : null;
            String smscAddr = addressOf(ind.getSMSCAddress());
            String mscAddr = addressOf(ind.getMscAddress());
            int serviceKey = ind.getServiceKey();

            System.out.println("=========================================");
            System.out.println("InitialDPSMS received from MSC/SMSC");
            System.out.println("  Service Key       : " + serviceKey);
            System.out.println("  Calling (A-party) : " + calling);
            System.out.println("  Called  (B-party) : " + called);
            System.out.println("  IMSI              : " + imsi);
            System.out.println("  SMSC GT           : " + smscAddr);
            System.out.println("  MSC GT            : " + mscAddr);
            System.out.println("  Event Type        : " + ind.getEventTypeSMS());
            System.out.println("=========================================");

            boolean hasEnoughBalance = checkBalance(calling);

            if (hasEnoughBalance) {

                System.out.println(
                        "[POLICY] Caller " + calling
                                + " has sufficient balance. Allowing SMS to "
                                + called + ".");

                /*
                 * Ask the network to notify us when the SMS is finally submitted
                 * to the SMSC or fails. notifyAndContinue means: "tell me, but do
                 * NOT pause the call again" — we have already approved it.
                 */
                java.util.ArrayList<SMSEvent> events = new java.util.ArrayList<>();
                events.add(new SMSEventImpl(
                        EventTypeSMS.oSmsSubmission,
                        MonitorMode.notifyAndContinue));
                events.add(new SMSEventImpl(
                        EventTypeSMS.oSmsFailure,
                        MonitorMode.notifyAndContinue));
                dialog.addRequestReportSMSEventRequest(events, null);

                /*
                 * ContinueSMS = "SCP says: proceed with the SMS as originally
                 * routed". This is the CAMEL way of expressing "balance OK,
                 * deliver the message".
                 */
                dialog.addContinueSMSRequest();

                dialog.send();

                System.out.println(
                        "[CAP] RequestReportSMSEvent + ContinueSMS sent for "
                                + calling + " -> " + called + ".");

            } else {

                System.out.println(
                        "[POLICY] Caller " + calling
                                + " has INSUFFICIENT balance. Releasing SMS to "
                                + called + ".");

                /*
                 * Deny the SMS. RPCause carries an SMS-RP cause value back to
                 * the originator (e.g. 27 = destination out of order, 29 =
                 * facility rejected, 38 = network out of order). Use whatever
                 * your billing/operator policy mandates.
                 *
                 *   RPCauseImpl cause = new RPCauseImpl(38);
                 *   dialog.addReleaseSMSRequest(cause);
                 *   dialog.send();
                 *   dialog.close(false);
                 *
                 * Left as a comment to keep this build dependency-free; wire it
                 * up when you implement real billing integration.
                 */
                dialog.addContinueSMSRequest();
                dialog.send();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Stub balance / policy check.
     *
     * Replace this with a real lookup against your billing/CRM/Diameter Sy/PCRF
     * for the given MSISDN. For now every caller is approved so the proxy always
     * answers ContinueSMS.
     */
    private boolean checkBalance(String callingMsisdn) {
        return true;
    }

    /**
     * Null-safe extraction of digits from a Mobicents address primitive.
     * Works for SMSAddressString, CalledPartyBCDNumber and ISDNAddressString —
     * all of them expose getAddress() returning the dialled digits.
     */
    private static String addressOf(Object addressPrimitive) {
        if (addressPrimitive == null) {
            return null;
        }
        try {
            return (String) addressPrimitive
                    .getClass()
                    .getMethod("getAddress")
                    .invoke(addressPrimitive);
        } catch (ReflectiveOperationException ignored) {
            return null;
        }
    }

    /**
     * Network informs us that the SMS we previously approved was either
     * submitted to the SMSC or failed. Log and close the dialog — our
     * involvement in this call is done.
     */
    @Override
    public void onEventReportSMSRequest(EventReportSMSRequest ind) {

        System.out.println(
                "[CAP] EventReportSMS received: "
                        + ind.getEventTypeSMS());

        try {
            ind.getCAPDialog().close(false);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*
     * Empty handlers
     */

    @Override
    public void onContinueSMSRequest(
            ContinueSMSRequest ind) {}

    @Override
    public void onReleaseSMSRequest(
            ReleaseSMSRequest ind) {}

    @Override
    public void onRequestReportSMSEventRequest(
            RequestReportSMSEventRequest ind) {}

    @Override
    public void onResetTimerSMSRequest(
            ResetTimerSMSRequest ind) {}

    @Override
    public void onConnectSMSRequest(
            ConnectSMSRequest ind) {}

    @Override
    public void onFurnishChargingInformationSMSRequest(
            FurnishChargingInformationSMSRequest ind) {}

    public void onDialogDelimiter(
            CAPDialog dialog) {}

    public void onDialogRelease(
            CAPDialog dialog) {}

    public void onDialogTimeout(
            CAPDialog dialog) {}

    public void onDialogUserAbort(
            CAPDialog dialog,
            CAPGeneralAbortReason reason,
            CAPUserAbortReason userReason) {}

    public void onDialogProviderAbort(
            CAPDialog dialog,
            PAbortCauseType cause) {}

    public void onDialogNotice(
            CAPDialog dialog,
            CAPNoticeProblemDiagnostic diag) {}

    @Override
    public void onErrorComponent(
            CAPDialog dialog,
            Long invokeId,
            CAPErrorMessage msg) {

        System.err.println(
                "[CAP ERROR] invokeId="
                        + invokeId
                        + " dialog="
                        + dialog
                        + " error="
                        + msg);
    }

    @Override
    public void onRejectComponent(
            CAPDialog dialog,
            Long invokeId,
            org.mobicents.protocols.ss7.tcap.asn.comp.Problem problem,
            boolean local) {

        System.err.println(
                "[CAP REJECT] invokeId="
                        + invokeId
                        + " local="
                        + local
                        + " problem="
                        + problem);
    }

    @Override
    public void onInvokeTimeout(
            CAPDialog dialog,
            Long invokeId) {

        System.err.println(
                "[CAP TIMEOUT] invokeId="
                        + invokeId
                        + " dialog="
                        + dialog);
    }

    @Override
    public void onCAPMessage(CAPMessage message) {

        CAPMessageType type =
                message != null ? message.getMessageType() : null;
        System.out.println(
                "[CAP RX] type="
                        + type
                        + " operationCode="
                        + (message != null ? message.getOperationCode() : -1));
    }
}
