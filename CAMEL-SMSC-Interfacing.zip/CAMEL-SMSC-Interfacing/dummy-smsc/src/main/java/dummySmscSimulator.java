import java.io.File;
import javax.xml.parsers.DocumentBuilderFactory;

import org.mobicents.protocols.api.Association;
import org.mobicents.protocols.api.IpChannelType;
import org.mobicents.protocols.sctp.ManagementImpl;

import org.mobicents.protocols.ss7.cap.CAPStackImpl;
import org.mobicents.protocols.ss7.cap.api.*;
import org.mobicents.protocols.ss7.cap.api.dialog.*;
import org.mobicents.protocols.ss7.cap.api.errors.CAPErrorMessage;
import org.mobicents.protocols.ss7.cap.api.primitives.*;
import org.mobicents.protocols.ss7.cap.api.service.sms.*;
import org.mobicents.protocols.ss7.cap.api.service.sms.primitive.EventTypeSMS;
import org.mobicents.protocols.ss7.cap.api.service.sms.primitive.SMSAddressString;
import org.mobicents.protocols.ss7.cap.primitives.CalledPartyBCDNumberImpl;
import org.mobicents.protocols.ss7.cap.service.sms.*;
import org.mobicents.protocols.ss7.cap.service.sms.primitive.SMSAddressStringImpl;
import org.mobicents.protocols.ss7.map.api.primitives.AddressNature;
import org.mobicents.protocols.ss7.map.api.primitives.ISDNAddressString;
import org.mobicents.protocols.ss7.map.primitives.ISDNAddressStringImpl;
import org.mobicents.protocols.ss7.tcap.asn.comp.PAbortCauseType;

import org.mobicents.protocols.ss7.indicator.*;

import org.mobicents.protocols.ss7.m3ua.ExchangeType;
import org.mobicents.protocols.ss7.m3ua.Functionality;
import org.mobicents.protocols.ss7.m3ua.IPSPType;
import org.mobicents.protocols.ss7.m3ua.impl.M3UAManagementImpl;
import org.mobicents.protocols.ss7.m3ua.impl.parameter.ParameterFactoryImpl;
import org.mobicents.protocols.ss7.m3ua.parameter.RoutingContext;
import org.mobicents.protocols.ss7.m3ua.parameter.TrafficModeType;
import org.mobicents.protocols.ss7.sccp.LoadSharingAlgorithm;
import org.mobicents.protocols.ss7.sccp.OriginationType;
import org.mobicents.protocols.ss7.sccp.RuleType;
import org.mobicents.protocols.ss7.sccp.impl.SccpStackImpl;
import org.mobicents.protocols.ss7.sccp.parameter.*;
import org.mobicents.protocols.ss7.sccp.impl.parameter.*;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

public class dummySmscSimulator
        implements CAPServiceSmsListener, CAPDialogListener {

    private CAPProvider capProvider;
    private ManagementImpl sctpManagement;
    private M3UAManagementImpl m3uaManagement;
    private SccpStackImpl sccpStack;

    private String localIp;
    private int localPort;
    private int localPointCode;
    private int localSsn;
    private String localGt;

    private String remoteIp;
    private int remotePort;
    private int remotePointCode;
    private int remoteSsn;
    private String remoteGt;
    private long routingContext;
    private int trafficMode;
    private int networkIndicator;

    private SccpAddress localAddress;
    private SccpAddress remoteAddress;

    /** Browser/API port for submitting SMS (see {@link SmsSubmitUiServer}). */
    private int httpUiPort = 8090;

    private final Object outboundLock = new Object();
    private OutboundSmsTicket currentOutbound;

    private static final class OutboundSmsTicket {

        final String calling;
        final String called;
        final String messageText;

        OutboundSmsTicket(String calling, String called, String messageText) {
            this.calling = calling;
            this.called = called;
            this.messageText = messageText;
        }
    }

    public static void main(String[] args)
            throws Exception {

        dummySmscSimulator sim =
                new dummySmscSimulator();

        sim.loadConfig();

        sim.initializeStack();
        System.out.println("Waiting for association to become UP...");
        sim.waitForAssociationUp(40000L);
        System.out.println(
                "SIGTRAN association is UP. Submit SMS from the HTTP UI or /api/send.");

        SmsSubmitUiServer ui = new SmsSubmitUiServer(sim, sim.httpUiPort);
        ui.start();

        Runtime.getRuntime().addShutdownHook(new Thread(ui::stopHttpServer));

        System.out.println(
                "HTTP UI: http://127.0.0.1:"
                        + sim.httpUiPort
                        + "/  (JSON POST http://127.0.0.1:"
                        + sim.httpUiPort
                        + "/api/send)");

        Thread.sleep(Long.MAX_VALUE);
    }

    ManagementImpl getSctpManagement() {
        return sctpManagement;
    }

    /**
     * Strip formatting; keeps digits only (leading {@code +} allowed).
     */
    public static String normalizeDigits(String raw) {

        if (raw == null) {
            return "";
        }
        String s = raw.trim();
        if (s.startsWith("+")) {
            s = s.substring(1);
        }
        return s.replaceAll("\\D", "");
    }

    /*
     * Load XML
     */

    private void loadConfig()
            throws Exception {

        Document doc =
                DocumentBuilderFactory
                .newInstance()
                .newDocumentBuilder()
                .parse(new File("config.xml"));

        this.localIp = getRequiredText(doc, "local-ip");
        this.localPort = Integer.parseInt(getRequiredText(doc, "local-port"));
        this.localPointCode = Integer.parseInt(getRequiredText(doc, "local-point-code"));
        this.localSsn = Integer.parseInt(getRequiredText(doc, "local-ssn"));
        this.localGt = getRequiredText(doc, "local-gt");

        this.remoteIp = getRequiredText(doc, "remote-ip");
        this.remotePort = Integer.parseInt(getRequiredText(doc, "remote-port"));
        this.remotePointCode = Integer.parseInt(getRequiredText(doc, "remote-point-code"));
        this.remoteSsn = Integer.parseInt(getRequiredText(doc, "remote-ssn"));
        this.remoteGt = getRequiredText(doc, "remote-gt");
        this.routingContext = Long.parseLong(getRequiredText(doc, "routing-context"));
        this.trafficMode = Integer.parseInt(getRequiredText(doc, "traffic-mode"));
        this.networkIndicator = Integer.parseInt(getRequiredText(doc, "network-indicator"));

        NodeList httpPortNodes = doc.getElementsByTagName("http-ui-port");
        if (httpPortNodes.getLength() > 0) {
            String hp = httpPortNodes.item(0).getTextContent();
            if (hp != null && !hp.trim().isEmpty()) {
                this.httpUiPort = Integer.parseInt(hp.trim());
            }
        }

        System.out.println(
                "Configuration loaded.");
    }

    /*
     * Initialize CAP stack
     */

    private void initializeStack()
            throws Exception {

        cleanupPersistedStackState();
        initM3uaAndSccp();

        CAPStackImpl capStack =
                new CAPStackImpl(
                        "dummySMSC",
                        this.sccpStack.getSccpProvider(),
                        this.localSsn);

        capStack.start();

        this.capProvider =
                capStack.getCAPProvider();

        this.capProvider
                .getCAPServiceSms()
                .addCAPServiceListener(this);

        this.capProvider
                .getCAPServiceSms()
                .acivate();

        /*
         * SCCP addresses
         */

        this.localAddress =
                new SccpAddressImpl(
                        RoutingIndicator
                        .ROUTING_BASED_ON_GLOBAL_TITLE,

                        createGlobalTitle(
                                this.localGt),

                        this.localPointCode,
                        this.localSsn);

        this.remoteAddress =
                new SccpAddressImpl(
                        RoutingIndicator
                        .ROUTING_BASED_ON_GLOBAL_TITLE,

                        createGlobalTitle(
                                this.remoteGt),

                        this.remotePointCode,
                        this.remoteSsn);

        System.out.println(
                "dummy SMSC initialized.");
    }

    private void cleanupPersistedStackState() {

        String[] filesToDelete = new String[] {
                "dummySMSC-SCTP_sctp.xml",
                "dummySMSC-M3UA_m3ua1.xml",
                "dummySMSC-SCCP_management2.xml",
                "dummySMSC-SCCP_sccprouter2.xml",
                "dummySMSC-SCCP_sccpresource2.xml",
                "dummySMSC_management.xml"
        };

        for (String fileName : filesToDelete) {
            try {
                new File(fileName).delete();
            } catch (Exception e) {
                // ignore cleanup failures and proceed with startup
            }
        }
    }

    /**
     * Builds CAP InitialDPSMS with correct parameter order for Mobicents
     * {@link InitialDPSMSRequestImpl} (destination BCD, calling SMS address, SMSC GT, …).
     *
     * <p>Message text is logged with delivery flow; TP‑UD packing for CAMEL inspection is not
     * implemented (would require full GSM 03.40 / RP‑DATA encoding).</p>
     */
    public void sendMoSmsToCamel(String callingDigits, String calledDigits, String messageText)
            throws CAPException {

        synchronized (outboundLock) {
            if (currentOutbound != null) {
                throw new IllegalStateException(
                        "Previous SMS still awaiting CAMEL response (calling="
                                + currentOutbound.calling
                                + " → called="
                                + currentOutbound.called
                                + "). Wait for ContinueSMS or restart.");
            }
            currentOutbound =
                    new OutboundSmsTicket(callingDigits, calledDigits, messageText);
        }

        CalledPartyBCDNumber destinationSubscriber =
                new CalledPartyBCDNumberImpl(
                        AddressNature.international_number,
                        org.mobicents.protocols.ss7.map.api.primitives.NumberingPlan.ISDN,
                        calledDigits);

        SMSAddressString callingParty =
                new SMSAddressStringImpl(
                        AddressNature.international_number,
                        org.mobicents.protocols.ss7.map.api.primitives.NumberingPlan.ISDN,
                        callingDigits);

        ISDNAddressString smscAddress =
                new ISDNAddressStringImpl(
                        AddressNature.international_number,
                        org.mobicents.protocols.ss7.map.api.primitives.NumberingPlan.ISDN,
                        normalizeDigits(localGt));

        ISDNAddressString calledPartyNumber =
                new ISDNAddressStringImpl(
                        AddressNature.international_number,
                        org.mobicents.protocols.ss7.map.api.primitives.NumberingPlan.ISDN,
                        calledDigits);

        CAPDialogSms dialog =
                this.capProvider
                        .getCAPServiceSms()
                        .createNewDialog(
                                CAPApplicationContext.CapV3_cap3_sms,
                                localAddress,
                                remoteAddress);

        final int invokeTimerMs = 30000;
        dialog.addInitialDPSMSRequest(
                invokeTimerMs,
                destinationSubscriber,
                callingParty,
                EventTypeSMS.smsCollectedInfo,
                null,
                null,
                null,
                smscAddress,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                calledPartyNumber);

        dialog.send();

        System.out.println(
                "[SMS SUBMIT] InitialDPSMS sent to CAMEL — calling="
                        + callingDigits
                        + " called="
                        + calledDigits
                        + " text=\""
                        + messageText.replace('\"', '\'')
                        + "\"");
    }

    /*
     * Receive ContinueSMS
     */

    @Override
    public void onContinueSMSRequest(
            ContinueSMSRequest ind) {

        OutboundSmsTicket ticket;
        synchronized (outboundLock) {
            ticket = currentOutbound;
        }

        if (ticket != null) {
            System.out.println(
                    "[SMS DELIVERY] CAMEL approved (ContinueSMS). Treating SMS as allowed for "
                            + "calling="
                            + ticket.calling
                            + " → called="
                            + ticket.called
                            + (ticket.messageText.isEmpty()
                                    ? ""
                                    : (" text=\"" + ticket.messageText.replace('\"', '\'') + "\"")));
        } else {
            System.out.println(
                    "ContinueSMS received (no pending UI ticket — unsolicited or duplicate).");
        }

        try {

            CAPDialogSms dialog =
                    (CAPDialogSms)
                    ind.getCAPDialog();

            /*
             * Simulate SMS success
             */

            dialog.addEventReportSMSRequest(
                    EventTypeSMS.oSmsSubmission,
                    null,
                    null,
                    null);

            dialog.send();

            System.out.println(
                    "EventReportSMS (oSmsSubmission) sent to CAMEL.");

            if (ticket != null) {
                System.out.println(
                        "[SMS COMPLETE] Message flow finished for calling="
                                + ticket.calling
                                + " → called="
                                + ticket.called
                                + " — subscriber SMS treated as delivered toward CAMEL policy.");

                synchronized (outboundLock) {
                    currentOutbound = null;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            synchronized (outboundLock) {
                currentOutbound = null;
            }
        }
    }

    /*
     * Receive ReleaseSMS
     */

    @Override
    public void onReleaseSMSRequest(
            ReleaseSMSRequest ind) {

        OutboundSmsTicket ticket;
        synchronized (outboundLock) {
            ticket = currentOutbound;
            currentOutbound = null;
        }

        if (ticket != null) {
            System.out.println(
                    "[SMS DENIED] CAMEL sent ReleaseSMS — calling="
                            + ticket.calling
                            + " → called="
                            + ticket.called);
        } else {
            System.out.println(
                    "ReleaseSMS received.");
        }

        try {

            ind.getCAPDialog()
                    .close(false);

            System.out.println(
                    "Dialog closed.");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*
     * Utility
     */

    private GlobalTitle createGlobalTitle(
            String digits) {

        return new GlobalTitle0100Impl(
                digits,
                0,
                BCDEvenEncodingScheme.INSTANCE,
                NumberingPlan.ISDN_TELEPHONY,
                NatureOfAddress.INTERNATIONAL);
    }

    private void initM3uaAndSccp()
            throws Exception {

        this.sctpManagement =
                new ManagementImpl("dummySMSC-SCTP");
        this.sctpManagement.setSingleThread(true);
        this.sctpManagement.start();
        this.sctpManagement.removeAllResourses();

        this.sctpManagement.addServer(
                "server-dummy-smsc",
                this.localIp,
                this.localPort,
                IpChannelType.TCP,
                null);
        this.sctpManagement.addServerAssociation(
                this.remoteIp,
                this.remotePort,
                "server-dummy-smsc",
                "assoc-dummy-smsc",
                IpChannelType.TCP);
        this.sctpManagement.startServer("server-dummy-smsc");

        this.m3uaManagement =
                new M3UAManagementImpl("dummySMSC-M3UA", null);
        this.m3uaManagement.setTransportManagement(this.sctpManagement);
        this.m3uaManagement.start();
        this.m3uaManagement.removeAllResourses();

        ParameterFactoryImpl pf =
                new ParameterFactoryImpl();
        RoutingContext rc =
                pf.createRoutingContext(new long[] { this.routingContext });
        TrafficModeType tmt =
                pf.createTrafficModeType(this.trafficMode);

        this.m3uaManagement.createAs(
                "AS1",
                Functionality.SGW,
                ExchangeType.SE,
                IPSPType.CLIENT,
                rc,
                tmt,
                1,
                null);

        this.m3uaManagement.createAspFactory(
                "ASP1",
                "assoc-dummy-smsc",
                false);
        this.m3uaManagement.assignAspToAs("AS1", "ASP1");
        this.sctpManagement.startAssociation("assoc-dummy-smsc");
        this.m3uaManagement.addRoute(
                this.remotePointCode,
                this.localPointCode,
                3,
                "AS1");

        this.sccpStack =
                new SccpStackImpl("dummySMSC-SCCP");
        this.sccpStack.setMtp3UserPart(1, this.m3uaManagement);
        this.sccpStack.start();
        this.sccpStack.removeAllResourses();

        this.sccpStack.getSccpResource()
                .addRemoteSpc(
                        1,
                        this.remotePointCode,
                        0,
                        0);

        this.sccpStack.getSccpResource()
                .addRemoteSsn(
                        1,
                        this.remotePointCode,
                        this.remoteSsn,
                        0,
                        false);

        this.sccpStack.getRouter()
                .addMtp3ServiceAccessPoint(
                        1,
                        1,
                        this.localPointCode,
                        this.networkIndicator,
                        0);

        this.sccpStack.getRouter()
                .addMtp3Destination(
                        1,
                        1,
                        this.remotePointCode,
                        this.remotePointCode,
                        0,
                        255,
                        255);

        SccpAddress remotePattern =
                new SccpAddressImpl(
                        RoutingIndicator.ROUTING_BASED_ON_GLOBAL_TITLE,
                        createGlobalTitle(this.remoteGt),
                        this.remotePointCode,
                        this.remoteSsn);
        this.sccpStack.getRouter().addRoutingAddress(1, remotePattern);
        this.sccpStack.getRouter().addRule(
                1,
                RuleType.SOLITARY,
                LoadSharingAlgorithm.Bit0,
                OriginationType.LOCAL,
                remotePattern,
                "K",
                1,
                -1,
                null,
                0);

        SccpAddress localPattern =
                new SccpAddressImpl(
                        RoutingIndicator.ROUTING_BASED_ON_GLOBAL_TITLE,
                        createGlobalTitle(this.localGt),
                        this.localPointCode,
                        this.localSsn);
        this.sccpStack.getRouter().addRoutingAddress(2, localPattern);
        this.sccpStack.getRouter().addRule(
                2,
                RuleType.SOLITARY,
                LoadSharingAlgorithm.Bit0,
                OriginationType.REMOTE,
                localPattern,
                "K",
                2,
                -1,
                null,
                0);

        // In SGW/server side mode we wait for peer ASPUP/ASPAC,
        // so we do not actively initiate ASPUP from this side.
    }

    private String getRequiredText(
            Document doc,
            String tagName) {

        String text =
                doc.getElementsByTagName(tagName)
                .item(0)
                .getTextContent();

        if (text == null || text.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "Missing config value for tag: " + tagName);
        }
        return text.trim();
    }

    private void waitForAssociationUp(long timeoutMs)
            throws Exception {

        long nextStatusAt = System.currentTimeMillis() + timeoutMs;
        while (true) {
            Association association =
                    this.sctpManagement.getAssociation("assoc-dummy-smsc");
            if (association != null && association.isUp()) {
                System.out.println("Association assoc-dummy-smsc is UP.");
                return;
            }

            if (System.currentTimeMillis() >= nextStatusAt) {
                System.out.println(
                        "Association assoc-dummy-smsc is not UP yet. "
                        + "Waiting for CAMEL connection...");
                nextStatusAt = System.currentTimeMillis() + timeoutMs;
            }
            Thread.sleep(250);
        }
    }

    /*
     * Empty handlers
     */

    @Override
    public void onInitialDPSMSRequest(
            InitialDPSMSRequest ind) {}

    @Override
    public void onEventReportSMSRequest(
            EventReportSMSRequest ind) {}

    @Override
    public void onRequestReportSMSEventRequest(
            RequestReportSMSEventRequest ind) {

        System.out.println(
                "RequestReportSMSEvent received.");
    }

    @Override
    public void onConnectSMSRequest(
            ConnectSMSRequest ind) {}

    @Override
    public void onResetTimerSMSRequest(
            ResetTimerSMSRequest ind) {}

    @Override
    public void onFurnishChargingInformationSMSRequest(
            FurnishChargingInformationSMSRequest ind) {}

    @Override
    public void onDialogDelimiter(
            CAPDialog dialog) {

        System.out.println(
                "DialogDelimiter");
    }

    @Override
    public void onDialogClose(
            CAPDialog dialog) {}

    @Override
    public void onDialogRequest(
            CAPDialog dialog,
            CAPGprsReferenceNumber ref) {}

    @Override
    public void onDialogAccept(
            CAPDialog dialog,
            CAPGprsReferenceNumber ref) {}

    @Override
    public void onDialogRelease(
            CAPDialog dialog) {}

    @Override
    public void onDialogTimeout(
            CAPDialog dialog) {}

    @Override
    public void onDialogUserAbort(
            CAPDialog dialog,
            CAPGeneralAbortReason reason,
            CAPUserAbortReason userReason) {}

    @Override
    public void onDialogProviderAbort(
            CAPDialog dialog,
            PAbortCauseType cause) {}

    @Override
    public void onDialogNotice(
            CAPDialog dialog,
            CAPNoticeProblemDiagnostic diag) {}

    @Override
    public void onErrorComponent(
            CAPDialog dialog,
            Long invokeId,
            CAPErrorMessage msg) {}

    @Override
    public void onRejectComponent(
            CAPDialog dialog,
            Long invokeId,
            org.mobicents.protocols.ss7
            .tcap.asn.comp.Problem problem,
            boolean local) {}

    @Override
    public void onInvokeTimeout(
            CAPDialog dialog,
            Long invokeId) {}

    @Override
    public void onCAPMessage(
            CAPMessage message) {}
}