import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.mobicents.protocols.api.Association;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

/**
 * Minimal browser UI + REST hook so operators can submit MO SMS parameters.
 * Uses JDK {@link HttpServer} only — no extra dependencies.
 */
public final class SmsSubmitUiServer {

    private static final String FORM_HTML =
            "<!DOCTYPE html><html><head><meta charset=\"UTF-8\"><title>dummy-smsc</title>"
                    + "<style>body{font-family:system-ui;max-width:42rem;margin:2rem auto;padding:0 1rem}"
                    + "label{display:block;margin:.6rem 0 .15rem}input,textarea{width:100%;box-sizing:border-box}"
                    + "button{margin-top:1rem;padding:.45rem 1rem}</style></head><body>"
                    + "<h1>dummy SMSC — submit CAMEL SMS</h1>"
                    + "<p>Requires SIGTRAN association UP (start CAMEL first). Sends CAP InitialDPSMS.</p>"
                    + "<form method=\"POST\" action=\"/send\" accept-charset=\"UTF-8\">"
                    + "<label>Calling number (A-party)</label>"
                    + "<input name=\"calling\" required placeholder=\"e.g. 6749990004\">"
                    + "<label>Called number (B-party)</label>"
                    + "<input name=\"called\" required placeholder=\"e.g. 6749990003\">"
                    + "<label>Message text</label>"
                    + "<textarea name=\"message\" rows=\"4\" placeholder=\"Logged on SMSC; not full TP-PDU\"></textarea>"
                    + "<button type=\"submit\">Send via CAP</button></form>"
                    + "<p><small>POST JSON to <code>/api/send</code> with "
                    + "<code>{\"calling\":\"...\",\"called\":\"...\",\"message\":\"...\"}</code></small></p>"
                    + "</body></html>";

    private final dummySmscSimulator simulator;
    private final int port;

    private HttpServer httpServer;
    private ExecutorService executor;

    public SmsSubmitUiServer(dummySmscSimulator simulator, int port) {
        this.simulator = simulator;
        this.port = port;
    }

    public void start() throws IOException {
        httpServer = HttpServer.create(new InetSocketAddress("127.0.0.1", port), 0);
        httpServer.createContext("/", new RootHandler());
        httpServer.createContext("/send", new PostSendHandler(false));
        httpServer.createContext("/api/send", new PostSendHandler(true));
        executor = Executors.newCachedThreadPool();
        httpServer.setExecutor(executor);
        httpServer.start();
    }

    public void stopHttpServer() {

        try {
            if (httpServer != null) {
                httpServer.stop(0);
                httpServer = null;
            }
        } catch (RuntimeException ignored) {
            // stop may fail during JVM teardown — ignore
        }
        if (executor != null) {
            executor.shutdown();
            executor = null;
        }
    }

    private boolean associationUp() {

        try {
            Association a =
                    simulator.getSctpManagement().getAssociation("assoc-dummy-smsc");
            return a != null && a.isUp();
        } catch (Exception e) {
            return false;
        }
    }

    private static void send(HttpExchange ex, int status, String contentType, byte[] body)
            throws IOException {

        ex.getResponseHeaders().set("Content-Type", contentType);
        ex.sendResponseHeaders(status, body.length);
        try (OutputStream os = ex.getResponseBody()) {
            os.write(body);
        }
    }

    private static String htmlEscape(String s) {
        if (s == null) {
            return "";
        }
        return s.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;");
    }

    private final class RootHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) throws IOException {
            if (!"GET".equalsIgnoreCase(ex.getRequestMethod())) {
                send(ex, 405, "text/plain", "Method Not Allowed\n".getBytes(StandardCharsets.UTF_8));
                return;
            }
            send(ex, 200, "text/html; charset=UTF-8", FORM_HTML.getBytes(StandardCharsets.UTF_8));
        }
    }

    private final class PostSendHandler implements HttpHandler {

        private final boolean jsonApi;

        PostSendHandler(boolean jsonApi) {
            this.jsonApi = jsonApi;
        }

        @Override
        public void handle(HttpExchange ex) throws IOException {
            if (!"POST".equalsIgnoreCase(ex.getRequestMethod())) {
                send(ex, 405, "text/plain", "Method Not Allowed\n".getBytes(StandardCharsets.UTF_8));
                return;
            }

            if (!associationUp()) {
                replyError(ex, 503, jsonApi, "SIGTRAN association is DOWN — start CAMEL and wait until link is UP.");
                return;
            }

            byte[] raw = ex.getRequestBody().readAllBytes();
            String calling;
            String called;
            String message;

            try {
                if (jsonApi) {
                    ParsedJson pj = parseJsonBody(new String(raw, StandardCharsets.UTF_8));
                    calling = pj.calling;
                    called = pj.called;
                    message = pj.message;
                } else {
                    Map<String, String> form = parseFormUrlEncoded(raw);
                    calling = form.get("calling");
                    called = form.get("called");
                    message = form.getOrDefault("message", "");
                }
            } catch (IllegalArgumentException e) {
                replyError(ex, 400, jsonApi, e.getMessage());
                return;
            }

            calling = dummySmscSimulator.normalizeDigits(calling);
            called = dummySmscSimulator.normalizeDigits(called);
            if (calling.isEmpty() || called.isEmpty()) {
                replyError(ex, 400, jsonApi, "calling and called must contain digits.");
                return;
            }

            try {
                simulator.sendMoSmsToCamel(calling, called, message == null ? "" : message.trim());
            } catch (Exception e) {
                replyError(ex, 500, jsonApi, e.getMessage());
                return;
            }

            if (jsonApi) {
                String ok =
                        "{\"ok\":true,\"calling\":\""
                                + escapeJson(calling)
                                + "\",\"called\":\""
                                + escapeJson(called)
                                + "\"}\n";
                send(ex, 200, "application/json; charset=UTF-8", ok.getBytes(StandardCharsets.UTF_8));
                return;
            }

            String page =
                    "<!DOCTYPE html><html><head><meta charset=\"UTF-8\"><title>Sent</title></head><body>"
                            + "<p><strong>InitialDPSMS sent</strong> to CAMEL for<br>"
                            + "calling=<code>"
                            + htmlEscape(calling)
                            + "</code><br>called=<code>"
                            + htmlEscape(called)
                            + "</code></p>"
                            + "<p>Watch SMSC logs for CAMEL approval and delivery summary.</p>"
                            + "<p><a href=\"/\">Submit another</a></p></body></html>";
            send(ex, 200, "text/html; charset=UTF-8", page.getBytes(StandardCharsets.UTF_8));
        }

        private void replyError(HttpExchange ex, int code, boolean json, String msg)
                throws IOException {

            if (json) {
                String body =
                        "{\"ok\":false,\"error\":\""
                                + escapeJson(msg)
                                + "\"}\n";
                send(ex, code, "application/json; charset=UTF-8", body.getBytes(StandardCharsets.UTF_8));
                return;
            }

            String page =
                    "<!DOCTYPE html><html><head><meta charset=\"UTF-8\"></head><body>"
                            + "<p style=\"color:#b00\"><strong>Error</strong>: "
                            + htmlEscape(msg)
                            + "</p><p><a href=\"/\">Back</a></p></body></html>";
            send(ex, code, "text/html; charset=UTF-8", page.getBytes(StandardCharsets.UTF_8));
        }
    }

    private static Map<String, String> parseFormUrlEncoded(byte[] raw) {

        String body = new String(raw, StandardCharsets.UTF_8);
        Map<String, String> map = new HashMap<>();
        for (String pair : body.split("&")) {
            if (pair.isEmpty()) {
                continue;
            }
            int eq = pair.indexOf('=');
            String key = eq >= 0 ? pair.substring(0, eq) : pair;
            String val = eq >= 0 ? pair.substring(eq + 1) : "";
            key = URLDecoder.decode(key, StandardCharsets.UTF_8);
            val = URLDecoder.decode(val, StandardCharsets.UTF_8);
            map.put(key, val);
        }
        return map;
    }

    private static final class ParsedJson {

        final String calling;
        final String called;
        final String message;

        ParsedJson(String calling, String called, String message) {
            this.calling = calling;
            this.called = called;
            this.message = message;
        }
    }

    /**
     * Tiny JSON parser for flat objects — avoids pulling Jackson/Gson into dummy-smsc.
     */
    private static ParsedJson parseJsonBody(String json) {

        if (json == null || json.trim().isEmpty()) {
            throw new IllegalArgumentException("Empty JSON body");
        }
        String calling = extractJsonString(json, "calling");
        String called = extractJsonString(json, "called");
        String message = extractJsonString(json, "message");
        if (message == null) {
            message = "";
        }
        if (calling == null || calling.trim().isEmpty()
                || called == null || called.trim().isEmpty()) {
            throw new IllegalArgumentException("JSON must include non-empty \"calling\" and \"called\".");
        }
        return new ParsedJson(calling, called, message);
    }

    private static String extractJsonString(String json, String field) {

        String needle = "\"" + field + "\"";
        int i = json.indexOf(needle);
        if (i < 0) {
            return "message".equals(field) ? "" : null;
        }
        int colon = json.indexOf(':', i + needle.length());
        if (colon < 0) {
            return null;
        }
        int startQuote = json.indexOf('"', colon + 1);
        if (startQuote < 0) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        for (int p = startQuote + 1; p < json.length(); p++) {
            char c = json.charAt(p);
            if (c == '"' && json.charAt(p - 1) != '\\') {
                break;
            }
            sb.append(c);
        }
        return sb.toString();
    }

    private static String escapeJson(String s) {
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r");
    }

    public int getPort() {
        return port;
    }
}
